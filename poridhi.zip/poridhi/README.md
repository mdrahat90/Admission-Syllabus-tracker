# PORIDHI · Syllabus & Admission Preparation Tracker

Mobile-first, offline-capable web app (installable on Android from Chrome: menu → "Add to Home screen").
Students pick a programme, then work through **Programme → Subjects → Chapters → Topics**, set each topic to
Not started / In progress / Studied / Needs revision, and see statistics computed from those statuses.

No build step, no dependencies, no backend. Progress lives in the student's browser (localStorage).

## The syllabus

`data/syllabus.js` holds the real syllabus (`poridhi_syllabus_seed.json`, catalogue version 2026.11):
3 programmes, 20 programme-subject entries, 204 chapters, 1,903 topics. It is the content authority: the app never
adds, renames, merges or drops a topic. The file itself says it is a coaching-based study map, **not** an official or
universal syllabus, and the app shows that wording (confirm screen → "Good to know", Profile → "Please note" and "Sources").

The importer reads that nested file directly. It has no subject or chapter IDs, so these are derived
deterministically (`<programme>/<subject>` and `<subject>/<paper-or-section>-<chapter no>`); progress is saved
against the file's own topic IDs (`POR-xxxx`), so it survives re-imports. Programme names are kept verbatim in the data;
the app shows the short name with the bracketed part as a sub line.

## Updating the syllabus

1. Open `admin.html` (same site, not linked from the student UI).
2. Choose the new file (nested JSON, relational JSON or CSV). Errors block the import, warnings are for review.
3. Either **Preview in the app on this device**, or **Download data/syllabus.js** and replace the file in `data/`.
4. Redeploy and bump `CACHE` in `sw.js` (currently `poridhi-v2`).

Saved statuses whose topic ID no longer exists are kept, left out of the counts and listed under Profile.

### Other accepted JSON format (relational, stable IDs)

```json
{
  "meta": { "title": "…", "syllabus_version": "2026.1", "source_notes": "…" },
  "programmes": [{ "programme_id": "eng", "programme_name": "Engineering", "admission_track": "Engineering", "institution_or_unit": "" }],
  "subjects":   [{ "subject_id": "phy", "subject_name": "Physics", "subject_order": 1, "programme_ids": ["eng", "med"] }],
  "chapters":   [{ "chapter_id": "phy-1", "subject_id": "phy", "chapter_name": "Mechanics", "chapter_number": "1", "chapter_order": 1 }],
  "topics":     [{ "topic_id": "phy-1-1", "chapter_id": "phy-1", "topic_name": "Kinematics", "topic_order": 1,
                   "applicability": "required", "coverage_layer": "HSC foundation",
                   "description": "", "source_reference": "" }]
}
```

Per-programme differences for a shared topic:

```json
"programmes": { "eng": { "coverage_layer": "Admission extension" }, "med": { "applicability": "excluded" } }
```

- `applicability`: `required`, `conditional`, `optional`, `excluded`. Excluded topics are hidden and never counted.
  If a file uses applicability anywhere, topics without a value are flagged **Unverified** (still counted).
- Topics with no `programmes`/`programme_ids` apply to every programme that includes their subject.
- Orders are kept exactly as supplied. IDs must be unique and stable: progress is saved by `topic_id`.

### CSV format (one row per topic per programme)

Required columns: `programme_id, programme_name, subject_id, subject_name, chapter_id, chapter_name, topic_id, topic_name`.
Optional: `admission_track, institution_or_unit, subject_order, chapter_number, chapter_order, topic_order, applicability, coverage_layer, description, source_reference, icon_key`.
A topic shared by several programmes appears once per programme. Comma, semicolon or tab separated, UTF-8 (Bengali is fine).
Export from Excel/Sheets as CSV.

## How numbers are calculated

Studied ÷ applicable topics, using topic counts at every level (never averages of percentages).
Needs revision, In progress and Not started do not count as studied. Display rounding never shows 0% or 100% unless it is exactly that.
Progress is stored per programme, so switching programmes never changes another programme's figures.
The weekly chart uses the real date each topic was first marked Studied; there is no fabricated history.

## If the syllabus changes later

Saved statuses are matched by `topic_id`. Records whose topic no longer exists, or no longer applies to the programme,
are kept (never deleted), excluded from the counts, and listed under Profile → "Saved statuses to review".

## Files

```
index.html  admin.html  manifest.webmanifest  sw.js
css/styles.css
js/core.js   validation, import, progress maths (no DOM; unit tested)
js/store.js  local storage, backup/restore
js/app.js    screens
js/admin.js  import/validation tool
data/syllabus.js   the real syllabus (nested JSON, loaded at runtime)
tests/       core.test.js, e2e.js (Playwright, phone viewport), fixtures/sample-syllabus.json (placeholder for tests only)
```

## Deploy

- **Vercel:** import the repo, framework preset "Other", no build command. Works with a private repo.
- **GitHub Pages:** Settings → Pages → deploy from `main` / root. On the free plan this needs a public repository.

Either way the site itself is public; only the code can be private. No student data leaves the device.

## Tests

```
node --test tests/core.test.js
python3 -m http.server 8765 &   # then:
node tests/e2e.js               # needs Playwright
```
